import { Time } from '@angular/common';

export class Comments {
    id: number;
    email: string;
    name: string;
    content: string;
    date: string;
}

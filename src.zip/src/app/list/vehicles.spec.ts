import { Comments } from './vehicles';

describe('Comments', () => {
 
});

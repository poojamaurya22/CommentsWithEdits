import { Component, OnInit, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { Comments } from '/park/src/app/list/vehicles';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-desc',
  templateUrl: './desc.component.html',
  styleUrls: ['./desc.component.css']
})
export class DescComponent implements OnInit{

  constructor(public datepipe: DatePipe, private httpClient: HttpClient) {}

  Comments : CommentList[];

  ngOnInit(){
    /*this.httpClient.get('http://localhost:3000/comments').subscribe((res: any[]) => {
      console.log(res);
      this.CommentList = res;
    });*/
  }

  @ViewChild("content", {static: false}) content: any;
  @ViewChild("reply", {static: false}) reply: any;
  
  newComment(){
    this.Comments.push({ id:'', author:'', content:this.content, date:'', reply: [] });
  }

  insertReply(index){
    this.Comments[index].reply.push({ author:'', content:this.reply, date:'' });
  }

}

class CommentList{
  id: string;
  author: string;
  content: string;
  date: String;
  reply: ReplyList[];
}

class ReplyList{
  author: string;
  content: string;
  date: String;
}



import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { DescComponent } from './desc/desc.component';
const routes: Routes = [
  { path: '', redirectTo: 'desc', pathMatch: 'full' },
  { path: 'desc', component: DescComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }